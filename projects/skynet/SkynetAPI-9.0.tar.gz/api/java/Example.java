import se.markstrom.skynet.api.SkynetAPI;

/**
 * This class is added to demonstrate example usage of the Skynet API.
 */
public class Example {

    /**
     * This method creates the Skynet API helper instance and prints some data.
     * See SkynetAPI class for details about all available API calls.
     *
     * @see se.markstrom.skynet.api.SkynetAPI
     */
    public static void runTests(String host, int port, String password, String protocol, boolean hashKnownHosts, boolean strictHostKeyChecking, boolean debug) {
        SkynetAPI api = null;
        try {
            SkynetAPI.Protocol p = SkynetAPI.Protocol.SSH;
            if (protocol.equals("telnet")) {
                p = SkynetAPI.Protocol.TELNET;
            }
            
            api = new SkynetAPI(host, port, p, password, hashKnownHosts, strictHostKeyChecking, debug);

            String areasXml = api.getAreasXml();
            System.out.println("Areas XML: " + areasXml);
            
            api.keepAlive();
        }
        catch (SkynetAPI.SkynetAPIError e) {
            e.printStackTrace();
        }
        if (api != null) {
            api.close();
        }
    }

    /**
     * Parses arguments and run tests.
     */
    public static void main(String[] arg) {
        switch (arg.length)
        {
        case 4:
        case 5:
            String host = arg[0];
            int port = Integer.parseInt(arg[1]);
            String password = arg[2];
			String protocol = arg[3];
            
            boolean debug = false;
            if (arg.length == 5) {
                debug = Boolean.parseBoolean(arg[4]);
            }

            Example.runTests(host, port, password, protocol, false, false, debug);
            break;
        
        default:
            printHelp();
            break;
        }
    }
    
    private static void printHelp() {
        System.out.println("Example <host> <port> <password> <protocol> [<debug>]");
    }
}
