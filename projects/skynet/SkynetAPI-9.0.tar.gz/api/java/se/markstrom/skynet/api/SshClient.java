package se.markstrom.skynet.api;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import com.jcraft.jsch.*;

/**
 * This class handles SSH communication with the Skynet API.
 */
class SshClient implements SkynetAPIClient {

    private static final int SESSION_CONNECT_TIMEOUT = 10000;
    private static final int CHANNEL_CONNECT_TIMEOUT = 10000;
    private static final String KNOWN_HOSTS_FILENAME = "SkynetAPI_ssh_known_hosts";

    private JSch jsch = null;
    private Session session = null;
    private Channel channel = null;
    
    private InputStream in = null;
    private OutputStream out = null;
    
    private static final int BUFFER_SIZE = 1024;
    private byte[] buffer = new byte[BUFFER_SIZE];

    public SshClient(String host, int port, String user, String password, boolean hashKnownHosts, boolean strictHostKeyChecking, boolean debug) throws SkynetAPIClientError {
        if (debug) {
            JSch.setLogger(new SshLogger());
        }
        
        jsch = new JSch();

        try {
            try {
                File knownHostsFile = new File(KNOWN_HOSTS_FILENAME);
                knownHostsFile.createNewFile();
            }
            catch (IOException e) {
                throw new SkynetAPIClientError(e);
            }
            
            jsch.setKnownHosts(KNOWN_HOSTS_FILENAME);

            session = jsch.getSession(user, host, port);
            session.setPassword(password);
            session.setConfig("PreferredAuthentications", "password");

            if (strictHostKeyChecking) {
                session.setConfig("StrictHostKeyChecking", "yes");
            }
            else {
	            session.setConfig("StrictHostKeyChecking", "no");
            }

            if (hashKnownHosts) {
                session.setConfig("HashKnownHosts", "yes");
            }
            else {
                session.setConfig("HashKnownHosts", "no");
            }

            session.connect(SESSION_CONNECT_TIMEOUT);
            channel = session.openChannel("shell");
            channel.connect(CHANNEL_CONNECT_TIMEOUT);
            
            in = channel.getInputStream();
            out = channel.getOutputStream();
        }
        catch (JSchException e) {
            throw new SkynetAPIClientError(e);
        }
        catch (IOException e) {
            throw new SkynetAPIClientError(e);
        }
    }
    
    @Override
    public String read() throws SkynetAPIClientError {
        try {
            if (in.available() > 0) {
                int i = in.read(buffer, 0, BUFFER_SIZE);
                if (i > 0) {
                	return new String(buffer, 0, i);
                }
            }
            
            if (channel.isClosed()) {
                throw new SkynetAPIClientError("Could not read due to SSH channel closed");
            }
            
            return null;
        }
        catch (IOException e) {
            throw new SkynetAPIClientError(e);
        }
    }
    
    @Override
    public void write(String data) throws SkynetAPIClientError {
        try {
            out.write(data.getBytes());
            out.flush();
        }
        catch (IOException e) {
            throw new SkynetAPIClientError(e);
        }
    }
    
    @Override
    public void close() {
        try { if (in != null) in.close(); } catch (IOException e) {}
        try { if (out != null) out.close(); } catch (IOException e) {}
        if (channel != null) {
            channel.disconnect();
            channel = null;
        }
        if (session != null) {
            session.disconnect();
            session = null;
        }
    }
    
    /**
     * A logger implementation to be used for JSch logging.
     */
    public static class SshLogger implements com.jcraft.jsch.Logger {
        static java.util.Hashtable name = new java.util.Hashtable();
        static {
            name.put(new Integer(DEBUG), "DEBUG: ");
            name.put(new Integer(INFO), "INFO: ");
            name.put(new Integer(WARN), "WARN: ");
            name.put(new Integer(ERROR), "ERROR: ");
            name.put(new Integer(FATAL), "FATAL: ");
        }
        
        public boolean isEnabled(int level) {
            return true;
        }
        
        public void log(int level, String message) {
            System.err.print(name.get(new Integer(level)));
            System.err.println(message);
        }
    }
}
