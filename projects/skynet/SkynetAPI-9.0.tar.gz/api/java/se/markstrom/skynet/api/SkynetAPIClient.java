package se.markstrom.skynet.api;

/**
 * This interface should be implemented by classes that handles Skynet API
 * communication.
 */
interface SkynetAPIClient {
	public abstract String read() throws SkynetAPIClientError;
	public abstract void write(String data) throws SkynetAPIClientError;
    public abstract void close();
}
