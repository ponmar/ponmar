package se.markstrom.skynet.api;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketTimeoutException;

/**
 * This class handles Telnet communication with the Skynet API.
 */
class TelnetClient implements SkynetAPIClient {
	
    private static final int READ_TIMEOUT = 1000;
    private static final int BUFFER_SIZE = 1024;
    
	private Socket socket = null;
	private InputStreamReader reader = null;
    private OutputStreamWriter writer = null;
    private char[] buffer = new char[BUFFER_SIZE];
	
	public TelnetClient(String host, int port) throws SkynetAPIClientError {
		try {
			socket = new Socket(host, port);
            socket.setSoTimeout(READ_TIMEOUT);
			reader = new InputStreamReader(socket.getInputStream());
            writer = new OutputStreamWriter(socket.getOutputStream());
		}
		catch (IOException e) {
			throw new SkynetAPIClientError(e);
		}
	}
	
	@Override
    public String read() throws SkynetAPIClientError {
		try {
            int i = reader.read(buffer, 0, BUFFER_SIZE);
            if (i > 0) {
                return new String(buffer, 0, i);
            }
            return null;
		}
        catch (SocketTimeoutException e) {
            return null;
        }
		catch (IOException e) {
			throw new SkynetAPIClientError(e);
		}
	}
	
	@Override
    public void write(String data) throws SkynetAPIClientError {
        try {
            writer.write(data);
            writer.flush();
        }
        catch (IOException e) {
            throw new SkynetAPIClientError(e);
        }
	}
	
	@Override
    public void close() {
		try {
			if (reader != null) {
				reader.close();
			}
			if (writer != null) {
				writer.close();
			}
			if (socket != null) {
				socket.close();
			}
		}
		catch (IOException e) {
			// Ignore
		}
	}
}
