package se.markstrom.skynet.api;

public class SkynetAPIClientError extends Exception {
    public SkynetAPIClientError(String message) {
        super(message);
    }

    public SkynetAPIClientError(Throwable cause) {
        super(cause);
    }

    public SkynetAPIClientError(String message, Throwable cause) {
        super(message, cause);
    }
}
