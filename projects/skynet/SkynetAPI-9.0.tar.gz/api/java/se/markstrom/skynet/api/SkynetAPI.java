package se.markstrom.skynet.api;

import com.jcraft.jsch.*;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * This is a helper class for developers that wants to use the Skynet API.
 *
 * Different protocols can be used for the communication.
 * A SkynetAPIError exception is thrown in error situations.
 *
 * A Skynet API user could, for example, inherit from this class and
 * implement wanted parsing of XML data returned by helper methods in this
 * class.
 * 
 * An instance of this class should be used from a single thread (it is not
 * thread safe).
 *
 * Note that the format of the XML and JSON data returned by some methods
 * below is not documented. The idea is that the format should be
 * self-explaining.
 *
 * @see SkynetAPIError
 */
public class SkynetAPI {
    
    public enum Protocol {
        SSH,
        TELNET
    }

    private static final String USER = "skynetapi";
    
    // Note: if \r\n linebreak is used two prompts can be returned, which causes problems
    private static final String LINEBREAK = "\n";

    private static final String PROMPT = ">> ";
    private static final int COMMAND_TIMEOUT = 30000;

    private SkynetAPIClient client = null;
    private final boolean debug;

    /**
     * Set ups a connection to a remote Skynet system.
     * 
     * @param host                  the hostname of the Skynet system
     * @param port                  the port for which the Skynet system accepts SSH connections
     * @param password              the SSH user password (set to null for Telnet session)
     * @param hashKnownHosts        set to true to add the SSH host key to the known hosts file (set to null for Telnet session)
     * @param strictHostKeyChecking set to true to use the SSH known hosts file (set to null for Telnet session)
     * @param debug                 set to true to get JSch debug printouts (set to null for Telnet session)
     */
    public SkynetAPI(String host, int port, Protocol protocol, String password, boolean hashKnownHosts, boolean strictHostKeyChecking, boolean debug) throws SkynetAPIError {
        this.debug = debug;

        try {
            switch (protocol) {
            case SSH:
                client = new SshClient(host, port, USER, password, hashKnownHosts, strictHostKeyChecking, debug);
                break;
            case TELNET:
                client = new TelnetClient(host, port);
                break;
            default:
                throw new SkynetAPIError("Unknown protocol");
            }
            
            readUntilPrompt(null);
        }
        catch (SkynetAPIClientError e) {
            throw new SkynetAPIError("Skynet API client error", e);
        }
    }

    /**
     * Call this method to close the Skynet API connection.
     */
    public void close() {
        if (client != null) {
            client.close();
        }
    }

    /**
     * Arm the system.
     *
     * @param delay   the delay before arming the system. Set to 0 for no delay.
     */
    public void arm(int delay) throws SkynetAPIError {
        if (delay > 0) {
            executeCommand("arm " + delay);
        }
        else {
            executeCommand("arm");
        }
    }

    /**
     * Disarm the system.
     *
     * @param delay   the delay before disarming the system. Set to 0 for no delay.
     */
    public void disarm(int delay) throws SkynetAPIError {
        if (delay > 0) {
            executeCommand("disarm " + delay);
        }
        else {
            executeCommand("disarm");
        }
    }
    
    /**
     * Disarm and arm after the specified delay.
     *
     * @param seconds   the time to be disarmed
     */
    public void tempDisarm(int seconds) throws SkynetAPIError {
        executeCommand("tempdisarm " + seconds);
    }

    /**
     * Lower event severity to info for specified event.
     *
     * @param eventId   the id of the Skynet event
     *                             -1 for all events
     *                             -2 for all minor events
     *                             -3 for all major events
     * @see #getEventsXml
     */
    public void acceptEvent(long eventId) throws SkynetAPIError {
        executeCommand("acceptevent " + eventId);
    }

    /**
     * Turn on a home automation device.
     *
     * @param deviceId   the id of the home automation control device
     * @param seconds    optional on-time (0 to keep on)
     * @see #getControlXml
     */
    public void turnOn(int deviceId, int seconds) throws SkynetAPIError {
        if (seconds > 0) {
            executeCommand("turnon " + deviceId + ' ' + seconds);
        }
        else {
            executeCommand("turnon " + deviceId);
        }
    }
    
    /**
     * Turn off a home automation device.
     *
     * @param deviceId   the id of the home automation control device
     * @see #getControlXml
     * @see #getControlJson
     */
    public void turnOff(int deviceId) throws SkynetAPIError {
        executeCommand("turnoff " + deviceId);
    }
    
    /**
     * Turn on all home automation devices.
     *
     * @see #getControlXml
     * @see #getControlJson
     */
    public void turnOnAll() throws SkynetAPIError {
        executeCommand("turnonall");
    }
    
    /**
     * Turn off all home automation devices.
     *
     * @see #getControlXml
     * @see #getControlJson
     */
    public void turnOffAll() throws SkynetAPIError {
        executeCommand("turnoffall");
    }

    /**
     * Send a line break to not be disconnected due to inactivity.
     * Any command can be used to get this behaviour, but this sends a minimum
     * amount of data and may increase readability of your application code.
     */
    public void keepAlive() throws SkynetAPIError {
        executeCommand("");
    }
    
    /**
     * Get XML data for areas.
     *
     * @return XML data in text format
     */
    public String getAreasXml() throws SkynetAPIError {
        return executeCommand("areas.xml");
    }

    /**
     * Get XML data for cameras.
     *
     * @return XML data in text format
     */
    public String getCamerasXml() throws SkynetAPIError {
        return executeCommand("cameras.xml");
    }

    /**
     * Get XML data for home automation.
     *
     * @return XML data in text format
     */
    public String getControlXml() throws SkynetAPIError {
        return executeCommand("control.xml");
    }

    /**
     * Get XML data for events.
     *
     * @return XML data in text format
     */
    public String getEventsXml() throws SkynetAPIError {
        return executeCommand("events.xml");
    }

    /**
     * Get XML data for log.
     *
     * @return XML data in text format
     */
    public String getLogXml() throws SkynetAPIError {
        return executeCommand("log.xml");
    }

    /**
     * Get XML data for sensors.
     *
     * @return XML data in text format
     */
    public String getSensorsXml() throws SkynetAPIError {
        return executeCommand("sensors.xml");
    }

    /**
     * Get XML data for services.
     *
     * @return XML data in text format
     */
    public String getServicesXml() throws SkynetAPIError {
        return executeCommand("services.xml");
    }

    /**
     * Get XML data for a system summary.
     *
     * @return XML data in text format
     */
    public String getSummaryXml() throws SkynetAPIError {
        return executeCommand("summary.xml");
    }

    /**
     * Get XML data for collected weather reports.
     *
     * @return XML data in text format
     */
    public String getWeatherXml() throws SkynetAPIError {
        return executeCommand("weather.xml");
    }

    /**
     * Get JSON data for areas.
     *
     * @return JSON data in text format
     */
    public String getAreasJson() throws SkynetAPIError {
        return executeCommand("areas.json");
    }

    /**
     * Get JSON data for cameras.
     *
     * @return JSON data in text format
     */
    public String getCamerasJson() throws SkynetAPIError {
        return executeCommand("cameras.json");
    }

    /**
     * Get JSON data for home automation.
     *
     * @return JSON data in text format
     */
    public String getControlJson() throws SkynetAPIError {
        return executeCommand("control.json");
    }

    /**
     * Get JSON data for events.
     *
     * @return JSON data in text format
     */
    public String getEventsJson() throws SkynetAPIError {
        return executeCommand("events.json");
    }

    /**
     * Get JSON data for log.
     *
     * @return JSON data in text format
     */
    public String getLogJson() throws SkynetAPIError {
        return executeCommand("log.json");
    }

    /**
     * Get JSON data for sensors.
     *
     * @return JSON data in text format
     */
    public String getSensorsJson() throws SkynetAPIError {
        return executeCommand("sensors.json");
    }

    /**
     * Get JSON data for services.
     *
     * @return JSON data in text format
     */
    public String getServicesJson() throws SkynetAPIError {
        return executeCommand("services.json");
    }

    /**
     * Get JSON data for a system summary.
     *
     * @return JSON data in text format
     */
    public String getSummaryJson() throws SkynetAPIError {
        return executeCommand("summary.json");
    }

    /**
     * Get JSON data for collected weather reports.
     *
     * @return JSON data in text format
     */
    public String getWeatherJson() throws SkynetAPIError {
        return executeCommand("weather.json");
    }
    
    /**
     * Get latest captured camera image.
     * Use <code>java.util.Base64</code> in Java 8 to decode base64 data.
     *
     * @param cameraIndex   the index of the source camera
     * @param preview       set to true to get a low resolution image
     * @return              a base64 encoded binary JPEG image
     * @see                 #getCamerasXml
     */
    public String getImageFromCamera(int cameraIndex, boolean preview) throws SkynetAPIError {
        if (preview) {
            return executeCommand("imagep " + cameraIndex);
        }
        else {
            return executeCommand("image " + cameraIndex);
        }
    }

    /**
     * Get image from event.
     * Use <code>java.util.Base64</code> in Java 8 to decode base64 data.
     *
     * @param eventId      the id of the Skynet event
     * @param imageIndex
     * @param preview      set to true to get a low resolution image
     * @return             a base64 encoded binary JPEG image
     * @see                #getEventsXml
     */
    public String getImageFromEvent(long eventId, int imageIndex, boolean preview) throws SkynetAPIError {
        if (preview) {
            return executeCommand("eventimagep " + eventId + " " + imageIndex);
        }
        else {
            return executeCommand("eventimage " + eventId + " " + imageIndex);
        }
    }
    
    /**
     * Internal method for executing a shell command.
     * This method can be used to add support for commands introduced in
     * a new minor revision of the Skynet API.
     *
     * @param command   the Skynet API shell command to execute
     * @return          shell output from command
     */
    private String executeCommand(String command) throws SkynetAPIError {
        try {
            client.write(command + LINEBREAK);
            return readUntilPrompt(command);
        }
        catch (SkynetAPIClientError e) {
            throw new SkynetAPIError("Could not execute Skynet API command", e);
        }
    }

    /**
     * Read data until the prompt is found in printed data.
     *
     * @param removeCommand   an optional command to be removed from printed data
     */
    private String readUntilPrompt(String removeCommand) throws SkynetAPIClientError {
        long endTime = System.currentTimeMillis() + COMMAND_TIMEOUT;
        String result = "";

        while (System.currentTimeMillis() < endTime) {
            String data = client.read();
            if (data != null) {
                // Remove extra line breaks
                result += data.replaceAll("(\\r|\\n)", "");
                
                int endPos = result.indexOf(PROMPT);
                if (endPos != -1) {
                    // Prompt found in received data
                    int startPos = 0;
                    if (removeCommand != null) {
                        // The command is only returned for SSH, not when using Telnet
                        if (result.startsWith(removeCommand)) {
                            startPos = removeCommand.length();
                        }
                    }
                    return result.substring(startPos, endPos);
                }
            }
            else {
                try { Thread.sleep(1); } catch (InterruptedException e) {}
            }
        }

        throw new SkynetAPIClientError("Time out while waiting for command prompt");
    }

    /**
     * An exception that is thrown in error situations by SkynetAPI.
     *
     * @see SkynetAPI
     */
    public class SkynetAPIError extends Exception {
        public SkynetAPIError(String message) {
            super(message);
        }

        public SkynetAPIError(Throwable cause) {
            super(cause);
        }

        public SkynetAPIError(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
