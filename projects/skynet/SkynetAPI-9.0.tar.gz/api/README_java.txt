Java API
========
The Skynet API helper class for Java requires JSch (Java Secure Channel),
which is included in binary form. Its license is included in the licenses
directory.

To use the API via Java you need to build SkynetAPI.jar:
>create_jar.bat

Java Examples
=============
* Example.java:
  This CLI print results of some Skynet API calls.

  Test with:
  >Example_compile.bat
  >Example_run.bat
