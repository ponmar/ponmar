"""This is a Skynet API application demo.

The API is used in a background thread to not block the
main (GUI) thread.

The program fetches and shows images from latest available events.
"""
import argparse
import utils
import pygame
import pygameapplication
import skynetapi

HEADING = 'Skynet Event Viewer - {}'
WINDOW_TITLE = 'Skynet Event Viewer [Host: {}:{}, Protocol: {}]'
ICON = 'icon.png'
SAVE_KEYS = [pygame.K_s]
QUIT_KEYS = [pygame.K_ESCAPE]

class EventViewer(pygameapplication.PygameApplication):
	"""Fetches Skynet event images and shows them in a GUI."""
	def __init__(self, host, port, protocol, pollDelay):
		self._eventImageFetcher = utils.LatestEventImageFetcher(True)
		fetchers = [self._eventImageFetcher, utils.Sleeper(pollDelay)]
		self._apiThread = utils.ApiUserThread(host, port, protocol, fetchers)

		title = WINDOW_TITLE.format(host, port, protocol)
		pygameapplication.PygameApplication.__init__(self, title=title, iconFilename=ICON)
		
		self._headingSurface = None
		self._image = None
		
	def close(self):
		super(EventViewer, self).close()
		if self._apiThread:
			self._apiThread.stop()

	def mouseButtonDown(self, button):
		pass
		
	def keyPressed(self, key):
		if key in SAVE_KEYS:
			if self._image:
				self._image.saveJpeg()
		elif key in QUIT_KEYS:
			self.quit()
		
	def runIteration(self):
		if not self._headingSurface and self._eventImageFetcher.json:
			site = self._eventImageFetcher.json['site']
			self._headingSurface = self.textToSurface(HEADING.format(site))

		if self._updateImage():
			self.draw()

		if not self._apiThread.is_alive():
			if self._apiThread.error:
				raise self._apiThread.error
			self.quit()

	def doDraw(self):
		if self._image:
			surface = self._image.getSurface()
		
			x = max(0, (self.getScreenSize()[0] - surface.get_width()) / 2)
			y = max(0, (self.getScreenSize()[1] - surface.get_height()) / 2)
			pos = (x, y)

			self.blitSurface(surface, pos)
		
		if self._headingSurface:
			x = max(0, (self.getScreenSize()[0] - self._headingSurface.get_width()) / 2)
			self.blitSurface(self._headingSurface, (x, 10))

	def _updateImage(self):
		image = self._eventImageFetcher.eventImage
		if image and (not self._image or image != self._image):
			self._image = image
			return True
		return False

def run(host, port, protocol, pollDelay):
	ev = None
	try:
		ev = EventViewer(host, port, protocol, pollDelay)
		ev.run()
	except KeyboardInterrupt:
		pass
	finally:
		if ev:
			ev.close()

if __name__ == '__main__':
	parser = argparse.ArgumentParser()
	parser.add_argument('host', help="the host running Skynet API")
	parser.add_argument('port', help="the port of the Skynet API", type=int)
	parser.add_argument('protocol', help='one of: ' + ', '.join(skynetapi.getSupportedProtocols()))
	parser.add_argument('polldelay', help="time between Skynet API calls in seconds", type=float)
	args = parser.parse_args()

	try:
		run(args.host, args.port, args.protocol, args.polldelay)
	except skynetapi.SkynetAPIError as e:
		print str(e)
		exit(2)
