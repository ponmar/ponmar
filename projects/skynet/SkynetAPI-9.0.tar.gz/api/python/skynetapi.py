"""This is a helper module for developers that wants to use the Skynet API.

Secure Shell (SSH) or Telnet protocol can be used. However, SSH requires that
Paramiko is installed. SSH should always be used when connecting via an
untrusted network such as the Internet.
"""
try:
	import paramiko
except ImportError:
	paramiko = None
import getpass
import time
import base64
import telnetlib
import socket
import json

DEFAULT_COMMAND_TIMEOUT = 30
SSH = 'ssh'
TELNET = 'telnet'
PROMPT = '>> '
SSH_EXCEPTIONS = None
if paramiko:
	# Note: see exceptions details here:
	#       http://docs.paramiko.org/en/1.15/api/ssh_exception.html
	SSH_EXCEPTIONS = (paramiko.ssh_exception.AuthenticationException,
	                  paramiko.ssh_exception.BadAuthenticationType,
	                  paramiko.ssh_exception.BadHostKeyException,
	                  paramiko.ssh_exception.ChannelException,
	                  paramiko.ssh_exception.PartialAuthentication,
	                  paramiko.ssh_exception.PasswordRequiredException,
	                  paramiko.ssh_exception.ProxyCommandFailure,
	                  paramiko.ssh_exception.SSHException)

def getSupportedProtocols():
	"""Use this function to get a list of available protocols that can be specified
	to the SkynetAPI constructor.
	"""
	protocols = [TELNET]
	if paramiko:
		protocols.append(SSH)
	return protocols

class SkynetAPI(object):
	"""This is a helper class for applications that needs information from a
	Skynet system. It sets up a connection to the specified host, executes
	commands in the Skynet shell and receives the output.
	
	SkynetAPIError is raised for all error situations. After a SkynetAPIError
	exception has been raised a new SkynetAPI instance must be initiated to
	continue using the Skynet API.
	
	A Skynet API user could, for example, inherit from this class and
	implement wanted parsing of XML data returned by methods in this class.
	
	An instance of this class should be used from a single thread (it is not
	thread safe).
	
	Note that the format of the XML data returned by some methods below is not
	documented. The idea is that the format should be self-explaining.
	"""
	def __init__(self, host, port, user = 'skynetapi', password = None, protocol = SSH):
		if protocol not in getSupportedProtocols():
			raise SkynetAPIError('Protocol not supported: ' + protocol)
	
		if protocol == SSH:
			self._client = _SshClient(host, port, user, password)
		elif protocol == TELNET:
			self._client = _TelnetClient(host, port)
		
		self._receiveUntilCommandPrompt(DEFAULT_COMMAND_TIMEOUT)

	def close(self):
		if self._client:
			self._client.close()

	def _sendCommand(self, command, linebreak = '\n'):
		self._client.write(command + linebreak)

	def _receiveUntilCommandPrompt(self, timeout):
		"""Receives all data until the command prompt is found in the data.
		None is returned if the timeout happens before that.
		"""
		data = ''
		while timeout >= 0:
			newData = self._client.read()
			if newData:
				data += newData
				promptPos = data.find(PROMPT)
				if promptPos != -1 and promptPos == (len(data) - len(PROMPT)):
					# Found prompt at end of received data
					return data[:promptPos]
			else:
				time.sleep(0.01)
				timeout -= 0.01
		return None

	def _executeCommand(self, command, timeout):
		self._sendCommand(command)
		return self._receiveUntilCommandPrompt(timeout)
	
	def arm(self, delay = None, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Arm the system."""
		if delay is None:
			self._executeCommand('arm', timeout)
		else:
			self._executeCommand('arm {}'.format(delay), timeout)

	def disarm(self, delay = None, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Disarm the system."""
		if delay is None:
			self._executeCommand('disarm', timeout)
		else:
			self._executeCommand('disarm {}'.format(delay), timeout)

	def tempDisarm(self, seconds, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Disarm and arm after the specified delay."""
		self._executeCommand('disarm {}'.format(seconds), timeout)
		
	def acceptEvent(self, eventId, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Lower event severity to major for specified event.
		Use eventId -1 for all events, -2 for all minor events or -3 for all major events.
		"""
		self._executeCommand('acceptevent {}'.format(eventId), timeout)
		
	def turnOn(self, deviceId, seconds = None, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Turn on a home automation device."""
		if seconds is None:
			self._executeCommand('turnon {}'.format(deviceId), timeout)
		else:
			self._executeCommand('turnon {} {}'.format(deviceId, seconds), timeout)

	def turnOff(self, deviceId, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Turn off a home automation device."""
		self._executeCommand('turnoff {}'.format(deviceId), timeout)

	def turnOnAll(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Turn on all home automation devices."""
		self._executeCommand('turnonall', timeout)
		
	def turnOffAll(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Turn off all home automation devices."""
		self._executeCommand('turnoffall', timeout)

	def getApiVersion(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns a tuple with the server side major and minor API version."""
		summaryJson = self.getSummaryJson(timeout)
		if summaryJson:
			json.loads(summaryJson)
			return summaryJson['majorapiversion'], summaryJson['minorapiversion']
		return None, None

	def verifyApiVersion(self, majorVersion, minorVersion = None, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns a boolean for if the server-side API version number is as wanted.
		If minorVersion is not specified it will not be verified.
		"""
		apiVersion = self.getApiVersion(timeout)
		if majorVersion != apiVersion[0]:
			return False
		if minorVersion is not None and minorVersion != apiVersion[1]:
			return False
		return True

	def keepAlive(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Send a line break to not be disconnected due to inactivity.
		Any command can be used to get this behaviour, but this sends a minimum
		amount of data and may increase readability of your application code.
		"""
		return self._executeCommand('', timeout)

	def getAreasXml(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns areas XML data."""
		return self._executeCommand('areas.xml', timeout)

	def getCamerasXml(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns cameras XML data."""
		return self._executeCommand('cameras.xml', timeout)

	def getControlXml(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns home automation control XML data."""
		return self._executeCommand('control.xml', timeout)
		
	def getEventsXml(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns events XML data."""
		return self._executeCommand('events.xml', timeout)

	def getLogXml(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns log XML data."""
		return self._executeCommand('log.xml', timeout)

	def getSensorsXml(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns sensors XML data."""
		return self._executeCommand('sensors.xml', timeout)

	def getServicesXml(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns services XML data."""
		return self._executeCommand('services.xml', timeout)

	def getSummaryXml(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns summary XML data."""
		return self._executeCommand('summary.xml', timeout)
		
	def getWeatherXml(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns weather XML data."""
		return self._executeCommand('weather.xml', timeout)

	def getAreasJson(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns areas JSON data."""
		return self._executeCommand('areas.json', timeout)

	def getCamerasJson(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns cameras JSON data."""
		return self._executeCommand('cameras.json', timeout)

	def getControlJson(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns home automation control JSON data."""
		return self._executeCommand('control.json', timeout)
		
	def getEventsJson(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns events JSON data."""
		return self._executeCommand('events.xml', timeout)

	def getLogJson(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns log JSON data."""
		return self._executeCommand('log.json', timeout)

	def getSensorsJson(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns sensors JSON data."""
		return self._executeCommand('sensors.json', timeout)

	def getServicesJson(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns services JSON data."""
		return self._executeCommand('services.json', timeout)

	def getSummaryJson(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns summary JSON data."""
		return self._executeCommand('summary.json', timeout)
		
	def getWeatherJson(self, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns weather JSON data."""
		return self._executeCommand('weather.json', timeout)
		
	def getImageFromCamera(self, cameraIndex, preview = False, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns latest jpeg image data from a camera.
		Set preview = True to get a low resolution image.
		Returns None if there was no such image.
		"""
		result = None
		if preview:
			result = self._executeCommand('imagep ' + str(cameraIndex), timeout)
		else:
			result = self._executeCommand('image ' + str(cameraIndex), timeout)
		if result:
			return self._decodeBase64(result)
		return None

	def getImageFromEvent(self, eventId, imageIndex, preview = False, timeout = DEFAULT_COMMAND_TIMEOUT):
		"""Returns jpeg image data from an event.
		Set preview = True to get a low resolution image.
		Returns None if there was no such image.
		"""
		result = None
		if preview:
			result = self._executeCommand('eventimagep {} {}'.format(eventId, imageIndex), timeout)
		else:
			result = self._executeCommand('eventimage {} {}'.format(eventId, imageIndex), timeout)
		if result:
			return self._decodeBase64(result)
		return None

	def _decodeBase64(self, data):
		if data:
			try:
				return base64.b64decode(data)
			except TypeError:
				pass
		return None

class SkynetAPIError(Exception):
	"""This exception is thrown in SkynetAPI error situations."""
	def __init__(self, message, value = None):
		self._message = message
		self._value = value

	def __str__(self):
		message = 'Skynet API Error: ' + self._message
		if self._value:
			message += '\nCaused by exception:\n' + repr(self._value)
		return message
		
class _SkynetAPIClient(object):
	def close(self):
		raise NotImplementedError
		
	def read(self):
		raise NotImplementedError
		
	def write(self):
		raise NotImplementedError

class _SshClient(_SkynetAPIClient):
	def __init__(self, host, port, user = 'skynet', password = None):
		try:
			while not password:
				password = getpass.getpass('Skynet API password: ')
			self._transport = paramiko.Transport((host, port))
			self._transport.connect(username = user, password = password)
			self._channel = self._transport.open_session()
			self._channel.setblocking(0)
			self._channel.invoke_shell()

		except SSH_EXCEPTIONS as e:
			raise SkynetAPIError('SSH problem', e)

	def close(self):
		if self._transport and self._transport.is_active():
			self._transport.close()
			
	def read(self):
		if self._channel.recv_ready():
			try:
				return self._channel.recv(1024)
			except (socket.error, socket.timeout) as e:
				raise SkynetAPIError('SSH socket problem', e)
		return None

	def write(self, data):
		try:
			if self._channel.send(data) != len(data):
				raise SkynetAPIError('Could not send all data via SSH')
		except (socket.error, socket.timeout) as e:
			raise SkynetAPIError('SSH socket problem', e)

class _TelnetClient(_SkynetAPIClient):
	# TODO: password support
	def __init__(self, host, port):
		try:
			self._telnet = telnetlib.Telnet(host, port)
		except socket.error as e:
			raise SkynetAPIError('Could not connect Telnet service at: {}:{}'.format(host, port), e)

	def close(self):
		if self._telnet:
			self._telnet.close()

	def read(self):
		try:
			return self._telnet.read_very_eager()
		except (EOFError, socket.error) as e:
			raise SkynetAPIError('Data coult not be read due to Telnet connection closed', e)

	def write(self, data):
		try:
			self._telnet.write(data)
		except socket.error as e:
			raise SkynetAPIError('Telnet socket error', e)
