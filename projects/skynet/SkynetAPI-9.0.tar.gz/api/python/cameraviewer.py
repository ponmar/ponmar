"""This is a Skynet API application demo.

The API is used in a background thread to not block the
main (GUI) thread.

The program fetches and shows images from the specified camera.

The showed images can be paused and it is possible to select
which image to show from a cache.

Images can also be saved to disk.

It is also possible to change selected camera.
"""
import argparse
import pygame
import skynetapi
import pygameapplication
import utils

ICON = 'icon.png'
WINDOW_TITLE = 'Skynet Camera Viewer [Host: {}:{}, Protocol: {}]'
HEADING = 'Skynet: {} - Camera {} - {}'
KEYREPEAT = 100
NUM_CACHED_IMAGES = 20
SAVE_KEYS = [pygame.K_s]
PAUSE_KEYS = [pygame.K_RETURN, pygame.K_SPACE, pygame.K_p]
LEFT_KEYS = [pygame.K_LEFT]
RIGHT_KEYS = [pygame.K_RIGHT]
QUIT_KEYS = [pygame.K_ESCAPE]

class CameraViewer(pygameapplication.PygameApplication):
	"""Fetches Skynet camera images and shows them in a GUI."""
	def __init__(self, host, port, protocol, pollDelay):
		self._cameraIndex = 0
		self._cameraImageFetcher = utils.CameraImageFetcher(self._cameraIndex)
		self._summaryJsonFetcher = utils.SummaryJsonFetcher()
		fetchers = [self._cameraImageFetcher, self._summaryJsonFetcher, utils.Sleeper(pollDelay)]
		self._apiThread = utils.ApiUserThread(host, port, protocol, fetchers)

		title = WINDOW_TITLE.format(host, port, protocol)
		pygameapplication.PygameApplication.__init__(self, title=title, iconFilename=ICON, keyRepeat=KEYREPEAT)
		
		self._site = None
		self._headingSurface = None
		self._images = []
		self._paused = False
		self._selectedIndex = 0
		
		self._changeCamera(self._cameraIndex)
		self._updateHeading()

	def close(self):
		super(CameraViewer, self).close()
		if self._apiThread:
			self._apiThread.stop()
		
	def mouseButtonDown(self, button):
		if button == 4:
			if self._changeImage(-1):
				self.draw()
			
		elif button == 5:
			if self._changeImage(1):
				self.draw()
		else:
			self._togglePause()
			self._updateHeading()
			self.draw()

	def keyPressed(self, key):
		if key in PAUSE_KEYS:
			self._togglePause()
			self._updateHeading()
			self.draw()
		elif key in LEFT_KEYS:
			if self._changeImage(-1):
				self.draw()
		elif key in RIGHT_KEYS:
			if self._changeImage(1):
				self.draw()
		elif key in SAVE_KEYS:
			self._saveImage()
		elif key in QUIT_KEYS:
			self.quit()
		elif key in range(pygame.K_1, pygame.K_9):
			self._changeCamera(key - pygame.K_0 - 1)
			self._updateHeading()
			self.draw()
		elif key in range(pygame.K_KP1, pygame.K_KP9):
			self._changeCamera(key - pygame.K_KP0 - 1)
			self._updateHeading()
			self.draw()

	def runIteration(self):
		if not self._site and self._summaryJsonFetcher.json:
			self._site = self._summaryJsonFetcher.json['site']
			self._updateHeading()
			self.draw()

		if not self._paused and self._updateImage():
			self.draw()

		if not self._apiThread.is_alive():
			if self._apiThread.error:
				raise self._apiThread.error
			self.quit()
			
	def doDraw(self):
		image = self._getImage()
		if image:
			surface = self._getImage().getSurface()
		
			x = max(0, (self.getScreenSize()[0] - surface.get_width()) / 2)
			y = max(0, (self.getScreenSize()[1] - surface.get_height()) / 2)

			self.blitSurface(surface, (x, y))

		if self._headingSurface:
			x = max(0, (self.getScreenSize()[0] - self._headingSurface.get_width()) / 2)
			self.blitSurface(self._headingSurface, (x, 10))

	def _togglePause(self):
		if self._images:
			self._paused = not self._paused
			if self._paused:
				self._selectedIndex = len(self._images) - 1

	def _changeImage(self, step):
		if self._paused:
			self._selectedIndex = max(0, min(self._selectedIndex + step, len(self._images) - 1))
			return True
		return False

	def _saveImage(self):
		image = self._getImage()
		if image:
			image.saveJpeg()

	def _getImage(self):
		if self._images:
			if self._paused:
				return self._images[self._selectedIndex]
			else:
				return self._images[-1]
		return None

	def _updateImage(self):
		image = self._cameraImageFetcher.image
		if image and (not self._images or self._images[-1] != image):
			self._images.append(image)
			if len(self._images) > NUM_CACHED_IMAGES:
				self._images = self._images[1:]
			return True
		return False
		
	def _updateHeading(self):
		status = None
		if self._paused:
			status = 'PAUSED'
		else:
			status = 'STREAMING'
		self._headingSurface = self.textToSurface(HEADING.format(self._site, self._cameraIndex+1, status))
		
	def _changeCamera(self, cameraIndex):
		self._cameraIndex = cameraIndex
		self._cameraImageFetcher.setCameraIndex(cameraIndex)
		self._images = []
		self._selectedIndex = 0
		self._paused = False
		
def run(host, port, protocol, pollDelay):
	cv = None
	try:
		cv = CameraViewer(host, port, protocol, pollDelay)
		cv.run()
	except KeyboardInterrupt:
		pass
	finally:
		if cv:
			cv.close()

if __name__ == '__main__':
	parser = argparse.ArgumentParser()
	parser.add_argument('host', help="the host running Skynet API")
	parser.add_argument('port', help="the port of the Skynet API", type=int)
	parser.add_argument('protocol', help='one of: ' + ', '.join(skynetapi.getSupportedProtocols()))
	parser.add_argument('polldelay', help="time between Skynet API calls in seconds", type=float)
	args = parser.parse_args()

	try:
		run(args.host, args.port, args.protocol, args.polldelay)
	except skynetapi.SkynetAPIError as e:
		print str(e)
		exit(1)
