"""
This example demonstrates a base class that reacts to new events by
polling the Skynet API.

A subclass called ImageWriter fetches any image attached to the
new events and writes them to disk.
"""
import argparse
import sys
import time
import datetime
import os.path
import json
import skynetapi

class EventRetriever(object):
	"""A helper base class that polls the Skynet API for new events.

	It is possible to inherit from this class and implement the handleNewEvent
	method.
	"""
	def __init__(self, host, port, protocol, pollDelay, writeDir):
		self._api = skynetapi.SkynetAPI(host, port, protocol=protocol)
		self._pollDelay = pollDelay
		self._writeDir = writeDir
		self._latestEventId = None

	def close(self):
		if self._api:
			self._api.close()

	def run(self):
		while True:
			summaryJson = self._api.getSummaryJson()
			if summaryJson:
				summaryJson = json.loads(summaryJson)
		
				latestEventId = summaryJson['latesteventid']
				if latestEventId != None and latestEventId != self._latestEventId:
					print 'New events detected {}'.format(datetime.datetime.now())
					self._updateEvents()
					self._latestEventId = latestEventId

			time.sleep(self._pollDelay)

	def _updateEvents(self):
		eventsJson = self._api.getEventsJson()
		if eventsJson:
			print 'Received updated event list from Skynet API'
			eventsJson = json.loads(eventsJson)
			
			for event in eventsJson:
				eventId = event['id']
				if eventId > self._latestEventId:
					time = event['time']
					message = event['message']
					sensor = event['sensor']
					areas = event['areas']
					severity = event['severity']
					armed = event['armed']
					numImages = event['numimages']
					
					self.handleNewEvent(eventId, time, message, sensor, areas, severity, armed, numImages)
		else:
			print 'Could not get event list from Skynet API'

	def handleNewEvent(self, eventId, time, message, sensor, areas, severity, armed, numImages):
		"""Override in sub class to make something with the event data."""
		print 'New event: {} {} {}'.format(eventId, message, numImages)

class ImageWriter(EventRetriever):
	"""Gets event images and writes them to disk."""
	def handleNewEvent(self, eventId, time, message, sensor, areas, severity, armed, numImages):
		for i in range(numImages):
			filename = '{}/{}_{}.jpg'.format(self._writeDir, eventId, i)
			if os.path.isfile(filename):
				print 'Image already written: {}'.format(filename)
			else:
				jpegData = self._api.getImageFromEvent(eventId, i)
				try:
					f = open(filename, 'wb')
					f.write(jpegData)
					f.close()
					print 'Image received and written to disk: {}'.format(filename)
				except IOError:
					print 'There was a problem writing {} to disk'.format(filename)

def runEventWriter(writer, host, port, protocol, pollDelay, writeDir):
	imageWriter = None
	try:
		imageWriter = writer(host, port, protocol, pollDelay, writeDir)
		imageWriter.run()
	except KeyboardInterrupt:
		pass
	finally:
		if imageWriter:
			imageWriter.close()

if __name__ == '__main__':
	parser = argparse.ArgumentParser()
	parser.add_argument('host', help="the host running Skynet API")
	parser.add_argument('port', help="the port of the Skynet API", type=int)
	parser.add_argument('protocol', help='one of: ' + ', '.join(skynetapi.getSupportedProtocols()))
	parser.add_argument('polldelay', help="time between Skynet API calls in seconds", type=float)
	parser.add_argument('writedir', help="the directory to write images to")
	args = parser.parse_args()

	try:
		runEventWriter(ImageWriter, args.host, args.port, args.protocol, args.polldelay, args.writedir)
	except skynetapi.SkynetAPIError as e:
		print str(e)
		exit(2)
