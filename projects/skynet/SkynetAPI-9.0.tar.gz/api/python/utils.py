import time
import threading
import json
import StringIO
import pygame
import skynetapi

class Image(object):
	"""A helper class for storing fetched images in memory."""
	def __init__(self, jpeg):
		self._jpeg = jpeg
		self._surface = None
		self._saved = False

	def __eq__(self, other):
		return self._jpeg == other._jpeg
		
	def __ne__(self, other):
		return not self == other

	def getSurface(self):
		if not self._surface:
			f = StringIO.StringIO(self._jpeg)
			self._surface = pygame.image.load(f, 'tmp.jpg')
			f.close()
		return self._surface
		
	def saveJpeg(self):
		if not self._saved:
			try:
				filename = '{}.jpg'.format(str(time.time()).replace('.', ''))
				with open(filename, 'wb') as f:
					f.write(self._jpeg)
				self._saved = True
			except IOError:
				pass
				
class CameraImageFetcher(object):
	"""An instance of this class can be used as a fetcher for ApiUserThread."""
	def __init__(self, cameraIndex):
		self._cameraIndex = cameraIndex
		self.image = None
		
	def run(self, api):
		jpeg = api.getImageFromCamera(self._cameraIndex)
		if jpeg:
			self.image = Image(jpeg)
		else:
			self.image = None
			
	def setCameraIndex(self, cameraIndex):
		self._cameraIndex = cameraIndex
		self.image = None

class _JsonFetcher(object):
	"""A helper class for JSON data fetchers."""
	def __init__(self):
		self.json = None
	
	def run(self, api):
		jsonStr = self.getJson(api)
		if jsonStr:
			self.json = json.loads(jsonStr)
			self.useJson(api)
	
	def getJson(self, api):
		raise NotImplementedError

	def useJson(self, api):
		pass

class SummaryJsonFetcher(_JsonFetcher):
	"""An instance of this class can be used as a fetcher for ApiUserThread."""
	def getJson(self, api):
		return api.getSummaryJson()

class LatestEventImageFetcher(SummaryJsonFetcher):
	"""An instance of this class can be used as a fetcher for ApiUserThread."""
	def __init__(self, fetchLatestEventImage = False):
		_JsonFetcher.__init__(self)
		self._fetchLatestEventImage = fetchLatestEventImage
		self._latestEventId = None
		self.eventImage = None

	def useJson(self, api):
		if self._fetchLatestEventImage:
			latestEventId = self.json['latesteventid']
			if latestEventId and latestEventId != self._latestEventId:
				if self._latestEventId:
					for eventId in range(latestEventId, self._latestEventId, -1):
						if self._getImageFromEvent(eventId, api):
							break
				else:
					self._getImageFromEvent(latestEventId, api)

				self._latestEventId = latestEventId
					
	def _getImageFromEvent(self, eventId, api):
		jpeg = api.getImageFromEvent(eventId, 0)
		if jpeg:
			self.eventImage = Image(jpeg)
			return True
		return False
		
class Sleeper(object):
	"""An instance of this class can be used as a fetcher for ApiUserThread."""
	def __init__(self, sleepTime=1.0, minSleepTime=0.1):
		self._sleepTime = sleepTime
		self._minSleepTime = minSleepTime
		self._prevUpdate = time.time()
		
	def run(self, api):
		now = time.time()
		passed = now - self._prevUpdate
		delay = max(self._minSleepTime, self._sleepTime - passed)
		time.sleep(delay)
		self._prevUpdate = time.time()

class ApiUserThread(threading.Thread):
	"""Fetches data from Skynet API in a new thread.
	This class can be used to not block the main (GUI) thread.
	
	Use a list of fetchers to get the needed Skynet information. This makes
	it possible to poll the fetchers for updated information.
	"""
	def __init__(self, host, port, protocol, fetchers):
		threading.Thread.__init__(self)
		
		self._api = skynetapi.SkynetAPI(host, port, protocol=protocol)
		self._run = True
		self._fetchers = fetchers
		self.error = None
		
		self.start()
		
	def run(self):
		try:
			#if not self._api.verifyApiVersion()
			#	print 'Wrong Skynet API version, please update your Skynet API helper module.'
		
			while self._run:
				for fetcher in self._fetchers:
					fetcher.run(self._api)

		except skynetapi.SkynetAPIError as e:
			self.error = e

		if self._api:
			self._api.close()

	def stop(self):
		self._run = False
		self.join()

