import time
import pygame

WINDOW_SIZE = (800, 600)
BACKGROUND_COLOR = (0, 0, 0)
FONT_SIZE = 24
TEXT_COLOR = (255, 0, 0)

class PygameApplication(object):
	"""A helper class that creates a Pygame window and handles window related events.
	Subclasses should implement methods that raises a NotImplementedError.
	"""
	def __init__(self, title = 'PygameApplication', backgroundColor = BACKGROUND_COLOR, iconFilename = None, keyRepeat = None):
		self._backgroundColor = backgroundColor
		self._run = True
	
		pygame.init()
		pygame.font.init()

		if iconFilename:
			icon = pygame.image.load(iconFilename)
			pygame.display.set_icon(icon)
		
		self._createWindow()
		pygame.display.set_caption(title)
		
		if keyRepeat:
			pygame.key.set_repeat(100, 100)
		pygame.event.set_blocked(pygame.MOUSEMOTION)

	def close(self):
		"""This cleanup method should be called when the application main loop is done."""
		if pygame.display.get_init():
			pygame.display.quit()
		
	def _createWindow(self, size = WINDOW_SIZE):
		flags = pygame.HWSURFACE | pygame.DOUBLEBUF | pygame.RESIZABLE
		self._screen = pygame.display.set_mode(size, flags)
		
	def _handleEvents(self):
		event = pygame.event.poll()
		if event.type == pygame.QUIT:
			self.quit()
		elif event.type == pygame.MOUSEBUTTONDOWN:
			self.mouseButtonDown(event.button)
		elif event.type == pygame.KEYDOWN:
			self.keyPressed(event.dict['key'])
		elif event.type == pygame.VIDEOEXPOSE:
			self.draw()
		elif event.type == pygame.VIDEORESIZE:
			newSize = event.dict['size']
			self._createWindow(newSize)
			self.draw()
		
	def mouseButtonDown(self, button):
		raise NotImplementedError
		
	def keyPressed(self, key):
		raise NotImplementedError
		
	def draw(self):
		self._screen.fill(self._backgroundColor)
		self.doDraw()
		pygame.display.flip()
	
	def doDraw(self):
		raise NotImplementedError
		
	def blitSurface(self, surface, pos):
		self._screen.blit(surface, pos)

	def fillRect(self, rect, color):
		pygame.draw.rect(self._screen, color, rect)

	def getScreenSize(self):
		return self._screen.get_size()
		
	def run(self):
		while self._run:
			self._handleEvents()
			self.runIteration()
			time.sleep(0.1)

	def runIteration(self):
		"""Override to execute application specific code in main thread."""
		raise NotImplementedError

	def quit(self):
		"""Call this method to stop the application main loop."""
		self._run = False

	def textToSurface(self, text, color = TEXT_COLOR, size = FONT_SIZE):
		font = pygame.font.SysFont(pygame.font.get_default_font(), size)
		return font.render(text, True, color)
