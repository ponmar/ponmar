Skynet API README
 - About
 - Requirements
 - Shell Command Interface (SSH/Telnet)
 - HTTP Interface
 - Network Discovery Service

About
=====
This package includes Skynet API documentation, helper classes and a few
examples for how to use them.

Currently only Java and Python is supported, but feel free to add support for
other languages and share!

For news and updates, please visit the Skynet web site:
http://pihack.no-ip.org/pontus/projects/skynet/

Have fun! /Pontus

Requirements
============
* A Skynet system with the API accessible from your device intended for using
  the Skynet API.

* Programming knowledge in either Python or Java.

Shell Command Interface (SSH/Telnet)
====================================
The shell command interface should be used via SSH to access the system
securely via an untrusted network such as the Internet. Port-forwarding can be
configured in your router to forward an external TCP port to port 22 in your
system.

Telnet should only be used via a local trusted network if SSH is not available.

The Python and Java APIs is using this shell command interface.

PuTTY can be used to access the shell command interface. Get PuTTY here:
http://www.chiark.greenend.org.uk/~sgtatham/putty/

HTTP Interface
==============
The Skynet web service is accessing Skynet via HTTP. Note that this API is not
supported and may be changed at any time without notice. It is also intended
for access via a local trusted network only, and should therefore not be
accessible via Internet (due to lack of encryption and authentication).

Network Discovery Service
=========================
The network discovery service can be used to find Skynet devices on the local
network.

Your client should listen on an UDP port. This port should be sent as four
bytes to your broadcast IP address port 9191. The network discovery service
will then send a response to the port you specified.

This is an example of the JSON formatted response:
{
	"name": "My Skynet",
	"telnetEnabled": 0,
	"httpPort": 8080,
	"apiVersion": "1.0",
	"sshPort": 22,
	"telnetPort": 9090
}

Note that you can receive many responses if you have more than one Skynet
device on your local network.

API Version Handling
====================
The API has its own major and minor version number. When the minor part is
stepped, the API is backwards compatible. When the major part is stepped it
means that at least one part of the API is not backwards compatible, meaning
that third party software using the Skynet API may need to be updated.
