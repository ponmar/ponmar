Python API
==========
The Skynet API helper class for Python requires Paramiko, that may be installed
with pip.

Python Examples
===============
* cameraviewer.py:
  A GUI that gets live images from cameras and shows them. The stream can be
  paused and previous images can be selected from a cache.
  Requires Pygame (http://www.pygame.org).

* eventviewer.py:
  A GUI that gets images from the latest available events.
  Requires Pygame (http://www.pygame.org).

* eventwriter.py:
  A console application that polls a Skynet instance for new events and saves
  all event images to a local directory.

